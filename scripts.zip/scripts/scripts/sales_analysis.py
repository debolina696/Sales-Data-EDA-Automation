import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

sns.set(style="whitegrid")


# ==============================
# LOAD DATA
# ==============================
def load_data(cleaned_path):
    file_path = os.path.join(cleaned_path, "cleaned_sales_data.csv")
    df = pd.read_csv(file_path)
    df["order_date"] = pd.to_datetime(df["order_date"])
    return df


# ==============================
# BASIC STATISTICS
# ==============================
def statistical_summary(df, reports_path):

    stats = pd.DataFrame({
        "mean": df.mean(numeric_only=True),
        "median": df.median(numeric_only=True),
        "std": df.std(numeric_only=True),
        "variance": df.var(numeric_only=True),
        "skewness": df.skew(numeric_only=True),
        "kurtosis": df.kurt(numeric_only=True)
    })

    stats.to_csv(os.path.join(reports_path, "statistical_summary.csv"))
    print("✅ Statistical summary saved")


# ==============================
# DISTRIBUTION PLOTS
# ==============================
def distribution_plots(df, reports_path):

    num_cols = df.select_dtypes(include="number").columns

    for col in num_cols:
        plt.figure()
        sns.histplot(df[col], kde=True)
        plt.title(f"{col} Distribution")

        plt.savefig(os.path.join(reports_path, f"{col}_distribution.png"))
        plt.close()

    print("✅ Distribution plots saved")


# ==============================
# OUTLIER DETECTION (Z-SCORE)
# ==============================
def detect_outliers(df, reports_path):

    from scipy.stats import zscore

    num_df = df.select_dtypes(include="number")
    z_scores = np.abs(zscore(num_df))

    outliers = df[(z_scores > 3).any(axis=1)]

    outliers.to_csv(os.path.join(reports_path, "outliers_report.csv"), index=False)

    print(f"✅ Outliers detected: {outliers.shape[0]}")


# ==============================
# KPI CALCULATION
# ==============================
def kpi_metrics(df, reports_path):

    total_sales = df["sales"].sum()
    total_profit = df["profit"].sum()
    total_orders = df.shape[0]

    kpi = pd.DataFrame({
        "Total Sales": [total_sales],
        "Total Profit": [total_profit],
        "Profit Margin (%)": [(total_profit / total_sales) * 100],
        "Avg Order Value": [total_sales / total_orders],
        "Avg Quantity": [df["quantity"].mean()]
    })

    kpi.to_csv(os.path.join(reports_path, "kpi_summary.csv"), index=False)

    print("✅ KPI metrics saved")


# ==============================
# TREND ANALYSIS
# ==============================
def trend_analysis(df, reports_path):

    df_trend = df.groupby("order_date")["sales"].sum().reset_index()

    plt.figure()
    plt.plot(df_trend["order_date"], df_trend["sales"])
    plt.title("Sales Trend Over Time")

    plt.savefig(os.path.join(reports_path, "trend_analysis.png"))
    plt.close()

    print("✅ Trend analysis saved")


# ==============================
# SIMPLE SALES FORECAST (MOVING AVG)
# ==============================
# IMPROVED SALES FORECAST (MONTHLY)

def forecast_sales(df, reports_path):

    if "order_date" in df.columns and "sales" in df.columns:

        print("📈 Creating Monthly Forecast...")

        # Convert date properly
        df["order_date"] = pd.to_datetime(df["order_date"])

        # Create monthly sales
        monthly_sales = df.resample(
            "M",
            on="order_date"
        )["sales"].sum()

        # Moving average forecast (3 months)
        forecast = monthly_sales.rolling(
            window=3
        ).mean()

        # Create plot
        plt.figure(figsize=(12,6))

        plt.plot(
            monthly_sales.index,
            monthly_sales,
            label="Actual Monthly Sales"
        )

        plt.plot(
            forecast.index,
            forecast,
            label="Forecast (Moving Avg)",
            linestyle="--"
        )

        plt.title("Monthly Sales Forecast")

        plt.xlabel("Month")

        plt.ylabel("Sales")

        plt.legend()

        plt.grid()

        plt.tight_layout()

        # SAVE FILE
        plt.savefig(
            os.path.join(
                reports_path,
                "sales_forecast.png"
            )
        )

        plt.show()

        print("✅ Monthly Forecast saved")


# ==============================
# MAIN FUNCTION
# ==============================
def run_statistics(cleaned_path, reports_path):

    print("🚀 Running Statistical Analysis...")

    df = load_data(cleaned_path)

    statistical_summary(df, reports_path)
    distribution_plots(df, reports_path)
    detect_outliers(df, reports_path)
    kpi_metrics(df, reports_path)
    trend_analysis(df, reports_path)
    forecast_sales(df, reports_path)

    print("✅ Statistical Analysis Completed")
