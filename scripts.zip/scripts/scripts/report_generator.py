from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image
from reportlab.platypus import Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors

import pandas as pd
import os


def generate_pdf_report(reports_path):

    print("📄 Generating Detailed PDF Report...")

    pdf_path = os.path.join(
        reports_path,
        "FINAL_REPORT.pdf"
    )

    doc = SimpleDocTemplate(pdf_path)

    styles = getSampleStyleSheet()

    elements = []

    # ======================
    # TITLE
    # ======================

    elements.append(
        Paragraph(
            "Sales Data Analysis Report",
            styles["Title"]
        )
    )

    elements.append(Spacer(1, 20))

    # ======================
    # EXECUTIVE SUMMARY
    # ======================

    summary_text = """
    <b>Executive Summary:</b><br/>
    This report presents an automated analysis of sales data including 
    data cleaning, exploratory analysis, statistical evaluation, and forecasting.
    The objective of this analysis is to understand business performance, 
    identify trends, detect unusual patterns, and support data-driven decision-making.
    """

    elements.append(
        Paragraph(summary_text, styles["BodyText"])
    )

    elements.append(Spacer(1, 20))

    # ======================
    # KPI TABLE
    # ======================

    kpi_file = os.path.join(
        reports_path,
        "kpi_summary.csv"
    )

    if os.path.exists(kpi_file):

        df_kpi = pd.read_csv(kpi_file)

        elements.append(
            Paragraph(
                "Key Performance Indicators",
                styles["Heading2"]
            )
        )

        data = [df_kpi.columns.tolist()] + df_kpi.values.tolist()

        table = Table(data)

        table.setStyle(
            TableStyle([
                ("GRID", (0,0), (-1,-1), 1, colors.black),
                ("BACKGROUND", (0,0), (-1,0), colors.lightgrey)
            ])
        )

        elements.append(table)

        elements.append(Spacer(1, 20))

        # KPI explanation text
        kpi_text = """
        <b>KPI Interpretation:</b><br/>
        The KPI metrics provide a high-level overview of business performance. 
        Total sales and total profit measure financial success, while profit margin 
        indicates operational efficiency. Average order value reflects customer 
        purchasing behavior, and average quantity supports inventory planning.
        """

        elements.append(
            Paragraph(kpi_text, styles["BodyText"])
        )

        elements.append(Spacer(1, 20))

    # ======================
    # BUSINESS INSIGHTS
    # ======================

    insight_text = """
    <b>Business Insights:</b><br/>
    The statistical distribution of sales and profit indicates stable business 
    performance across transactions. The correlation analysis highlights relationships 
    between key numerical variables such as quantity, sales, and profit. 
    Trend analysis reveals the time-based movement of sales, while forecasting 
    predicts future performance using historical patterns.
    """

    elements.append(
        Paragraph(insight_text, styles["BodyText"])
    )

    elements.append(Spacer(1, 20))

    # ======================
    # ADD CHARTS
    # ======================

    charts = [
        "sales_distribution.png",
        "profit_distribution.png",
        "quantity_distribution.png",
        "trend_analysis.png",
        "sales_forecast.png",
        "correlation.png"
    ]

    for chart in charts:

        chart_path = os.path.join(
            reports_path,
            chart
        )

        if os.path.exists(chart_path):

            elements.append(
                Paragraph(
                    chart.replace(".png", ""),
                    styles["Heading2"]
                )
            )

            img = Image(
                chart_path,
                width=400,
                height=250
            )

            elements.append(img)

            elements.append(Spacer(1, 20))

    # ======================
    # FINAL RECOMMENDATIONS
    # ======================

    recommendation_text = """
    <b>Recommendations:</b><br/>
    Based on the analysis, it is recommended to monitor high-performing products, 
    optimize pricing strategies, and maintain inventory alignment with demand patterns. 
    Future forecasting models may be enhanced using advanced time-series methods 
    to improve prediction accuracy.
    """

    elements.append(
        Paragraph(recommendation_text, styles["BodyText"])
    )

    elements.append(Spacer(1, 20))

    # ======================
    # BUILD PDF
    # ======================

    doc.build(elements)

    print("✅ Detailed PDF Report Generated Successfully")
