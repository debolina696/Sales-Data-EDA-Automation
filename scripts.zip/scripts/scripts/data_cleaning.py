import pandas as pd
import numpy as np
import os

# LOAD DATA
def load_data(raw_path):
    df_list = []

    for file in os.listdir(raw_path):
        file_path = os.path.join(raw_path, file)

        if file.endswith(".csv"):
            print(f"Loading CSV: {file}")
            df = pd.read_csv(file_path)
            df_list.append(df)

    if len(df_list) == 0:
        raise ValueError("❌ No CSV files found in raw folder")

    return pd.concat(df_list, ignore_index=True)


# STANDARDIZE COLUMNS
def standardize_columns(df):
    df.columns = (
        df.columns
        .str.strip()
        .str.lower()
        .str.replace(" ", "_")
    )
    return df


# TRIM DATA
def trim_data(df):
    for col in df.select_dtypes(include="object").columns:
        df[col] = df[col].astype(str).str.strip()
    return df


# FIX DATE
def fix_date_columns(df):
    for col in df.columns:
        if "date" in col:
            print(f"Fixing date: {col}")
            df[col] = pd.to_datetime(df[col], errors="coerce")
    return df


# REMOVE DUPLICATES
def remove_duplicates(df):
    if "order_id" in df.columns:
        print("Removing duplicates based on order_id")
        return df.drop_duplicates(subset=["order_id"])
    return df.drop_duplicates()


# HANDLE NULLS
def handle_nulls(df):
    num_cols = df.select_dtypes(include=np.number).columns
    df[num_cols] = df[num_cols].fillna(df[num_cols].median())

    cat_cols = df.select_dtypes(include="object").columns
    for col in cat_cols:
        if not df[col].mode().empty:
            df[col] = df[col].fillna(df[col].mode()[0])
        else:
            df[col] = df[col].fillna("Unknown")

    return df


# HANDLE OUTLIERS
def handle_outliers(df):
    num_cols = df.select_dtypes(include=np.number).columns

    for col in num_cols:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1

        lower = Q1 - 1.5 * IQR
        upper = Q3 + 1.5 * IQR

        df[col] = np.where(df[col] < lower, lower,
                  np.where(df[col] > upper, upper, df[col]))

    return df


# MAIN FUNCTION
def clean_data(raw_path, cleaned_path):

    print("🚀 Starting Cleaning...")

    df = load_data(raw_path)
    print("Raw Shape:", df.shape)

    df = standardize_columns(df)
    df = trim_data(df)
    df = fix_date_columns(df)
    df = remove_duplicates(df)
    df = handle_nulls(df)
    df = handle_outliers(df)

    print("Cleaned Shape:", df.shape)

    output_file = os.path.join(cleaned_path, "cleaned_sales_data.csv")
    df.to_csv(output_file, index=False)

    print("✅ Saved at:", output_file)

    return df

