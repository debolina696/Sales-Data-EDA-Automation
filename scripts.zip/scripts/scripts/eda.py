import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

sns.set(style="whitegrid")


# LOAD DATA
def load_clean_data(cleaned_path):
    file_path = os.path.join(cleaned_path, "cleaned_sales_data.csv")
    df = pd.read_csv(file_path)
    print("Data Loaded:", df.shape)
    return df


# SAVE SUMMARY
def save_summary(df, reports_path):
    summary = df.describe()
    file_path = os.path.join(reports_path, "summary_report.csv")
    summary.to_csv(file_path)
    print("✅ Summary saved")


# SALES TREND
def sales_trend(df, reports_path):
    if "order_date" in df.columns and "sales" in df.columns:
        df["order_date"] = pd.to_datetime(df["order_date"])
        df = df.sort_values("order_date")

        plt.figure()
        plt.plot(df["order_date"], df["sales"])
        plt.title("Sales Trend")

        plt.savefig(os.path.join(reports_path, "sales_trend.png"))
        plt.show()


# TOP PRODUCTS
def top_products(df, reports_path):
    if "product_name" in df.columns and "sales" in df.columns:
        top = df.groupby("product_name")["sales"].sum().head(10)

        plt.figure()
        top.plot(kind="bar")
        plt.title("Top Products")

        plt.savefig(os.path.join(reports_path, "top_products.png"))
        plt.show()


# REGION SALES
def region_sales(df, reports_path):
    if "region" in df.columns and "sales" in df.columns:
        region = df.groupby("region")["sales"].sum()

        plt.figure()
        region.plot(kind="bar")
        plt.title("Region Sales")

        plt.savefig(os.path.join(reports_path, "region_sales.png"))
        plt.show()


# CORRELATION
def correlation(df, reports_path):
    num_df = df.select_dtypes(include="number")

    plt.figure()
    sns.heatmap(num_df.corr(), annot=True)
    plt.title("Correlation")

    plt.savefig(os.path.join(reports_path, "correlation.png"))
    plt.show()


# MAIN FUNCTION
def run_eda(cleaned_path, reports_path):

    print("🚀 Running EDA...")

    df = load_clean_data(cleaned_path)

    save_summary(df, reports_path)
    sales_trend(df, reports_path)
    top_products(df, reports_path)
    region_sales(df, reports_path)
    correlation(df, reports_path)

    print("✅ All reports saved in reports folder")
