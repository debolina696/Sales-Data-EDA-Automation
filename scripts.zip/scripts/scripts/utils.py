# ==========================================
# UTILITY FUNCTIONS
# ==========================================

import os
import shutil
from datetime import datetime


# CREATE FOLDER IF NOT EXISTS
def create_folder(path):

    if not os.path.exists(path):

        os.makedirs(path)

        print(f"📁 Folder created: {path}")

    else:

        print(f"📁 Folder already exists: {path}")


# CHECK FILE EXISTS
def check_file(path):

    if os.path.exists(path):

        print(f"✅ File found: {path}")

        return True

    else:

        print(f"❌ File missing: {path}")

        return False


# PRINT PROJECT PATHS
def print_paths(raw_path, cleaned_path, reports_path):

    print("\n📂 Project Paths:")

    print("Raw Path:", raw_path)

    print("Cleaned Path:", cleaned_path)

    print("Reports Path:", reports_path)


# ==========================================
# ARCHIVE OLD FILES
# ==========================================

def archive_old_files(source_folder, archive_folder):

    # Skip if folder doesn't exist
    if not os.path.exists(source_folder):
        return

    files = os.listdir(source_folder)

    # Skip if empty
    if len(files) == 0:
        print(f"📁 No files to archive in {source_folder}")
        return

    # Create archive folder if missing
    os.makedirs(archive_folder, exist_ok=True)

    # Create timestamp folder
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

    archive_path = os.path.join(
        archive_folder,
        timestamp
    )

    os.makedirs(archive_path, exist_ok=True)

    # Move files
    for file in files:

        src = os.path.join(source_folder, file)

        if os.path.isfile(src):

            dst = os.path.join(
                archive_path,
                file
            )

            shutil.move(src, dst)

    print(f"📦 Archived files from {source_folder}")
