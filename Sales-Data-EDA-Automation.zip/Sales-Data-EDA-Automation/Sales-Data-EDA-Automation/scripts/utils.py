# ==========================================
# UTILITY FUNCTIONS
# ==========================================

import os


# CREATE FOLDER IF NOT EXISTS
def create_folder(path):

    if not os.path.exists(path):

        os.makedirs(path)

        print(f"📁 Folder created: {path}")

    else:

        print(f"📁 Folder already exists: {path}")


# CHECK FILE EXISTS
def check_file(path):

    if os.path.exists(path):

        print(f"✅ File found: {path}")

        return True

    else:

        print(f"❌ File missing: {path}")

        return False


# PRINT PROJECT PATHS
def print_paths(raw_path, cleaned_path, reports_path):

    print("\n📂 Project Paths:")

    print("Raw Path:", raw_path)

    print("Cleaned Path:", cleaned_path)

    print("Reports Path:", reports_path)
